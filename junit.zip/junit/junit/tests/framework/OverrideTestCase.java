package junit.tests.framework;

/**
 * Test class used in SuiteTest
 */
public class OverrideTestCase extends OneTestCase {
	public void testCase() {
	}
}