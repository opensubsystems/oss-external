package org.bouncycastle.sasn1;

class BerTagClass
{
    public static final int UNIVERSAL           = 0x00;
    public static final int APPLICATION         = 0x40;
}
