package org.bouncycastle.sasn1;

import java.io.InputStream;

public interface Asn1OctetString 
{   
    public InputStream getOctetStream();
}
